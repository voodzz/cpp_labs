#pragma once

#include <string>

const std::string MIN_CODE = "nim";
const std::string MAX_CODE = "xam";

int evalMinMaxExpression(const std::string&);
